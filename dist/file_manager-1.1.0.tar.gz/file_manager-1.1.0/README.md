# File Manager for FastAPI

A plug-and-play solution for managing file uploads in FastAPI apps. It handles file uploads, saves them uniquely, and serves them via a static route automatically.

## Installation

Install using pip:

```bash
pip install file-manager
